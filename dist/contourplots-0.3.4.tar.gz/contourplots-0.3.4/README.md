# contourplots
Tools for lively contour plot generation, including representation of 4-dimensional data.
